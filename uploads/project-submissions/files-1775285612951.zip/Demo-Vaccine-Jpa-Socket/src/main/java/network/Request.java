/*
 * @(#) Exer1.java 1.0 27/08/2024
 *
 * Copyright (c) 2024 IUH
 */

package network;

import lombok.*;

import java.io.Serializable;

/*
 * @description: This class represents a bank with many bank accounts
 * @author : Nguyen Huy Hoang
 * @version 1.0
 * @created :27-Aug-2024 10:41:50 AM
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class Request implements Serializable {
    private CommandType commandType;
    private  Object data;
}
