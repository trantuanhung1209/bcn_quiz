/*
 * @(#) Exer1.java 1.0 27/08/2024
 *
 * Copyright (c) 2024 IUH
 */

package network;

import dto.RecordDTO;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {
    public static void main(String[] args) {
        try (
            ServerSocket serverSocket = new ServerSocket(1234);
            ExecutorService pool = Executors.newFixedThreadPool(10)
        ) {
            System.out.println("Server started on port 1234");

            while (true) {
                Socket socket = serverSocket.accept();
                pool.submit(new RequestHandler(socket));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static class RequestHandler implements Runnable {
        private final Socket socket;

        RequestHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream())
            ) {
                while (true) {
                    Object obj = in.readObject();
                    if (!(obj instanceof Request)) {
                        out.writeObject(new Respond(false, "Invalid request type"));
                        out.flush();
                        continue;
                    }

                    Request request = (Request) obj;
                    Respond respond = handleRequest(request);
                    out.writeObject(respond);
                    out.flush();
                }
            } catch (Exception e) {
                System.out.println("Client disconnected: " + socket.getInetAddress());
            }
        }

        private Respond handleRequest(Request request) {
            switch (request.getCommandType()) {
                case CREATE_CORD:
                    Object data = request.getData();
                    boolean valid = data instanceof RecordDTO;
                    return new Respond(valid, valid ? "CREATE_CORD handled" : "Invalid RecordDTO payload");
                case UPDATE_CORD:
                    return new Respond(true, "UPDATE_CORD handled");
                case LIST_OBESE_PEOPLE:
                    return new Respond(true, "LIST_OBESE_PEOPLE handled");
                case COUNT_VACCINES:
                    return new Respond(true, "COUNT_VACCINES handled");
                default:
                    return new Respond(false, "Unsupported command");
            }
        }
    }
}
