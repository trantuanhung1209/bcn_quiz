/*
 * @(#) Exer1.java 1.0 27/08/2024
 *
 * Copyright (c) 2024 IUH
 */

package network;

/*
 * @description: This class represents a bank with many bank accounts
 * @author : Nguyen Huy Hoang
 * @version 1.0
 * @created :27-Aug-2024 10:41:50 AM
 */

import dto.RecordDTO;
import entity.DoseStatus;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.time.LocalDate;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try (
            Socket socket = new Socket("localhost", 1234);
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            Scanner input = new Scanner(System.in)
        ) {
            while (true) {
                System.out.println("\nMenu:");
                System.out.println("1. Create record");
                System.out.println("2. Update record");
                System.out.println("3. List obese people");
                System.out.println("4. Count vaccines");
                System.out.println("0. Exit");
                System.out.print("Choose: ");

                int choice;
                try {
                    choice = Integer.parseInt(input.nextLine().trim());
                } catch (NumberFormatException e) {
                    System.out.println("Invalid number, try again.");
                    continue;
                }

                if (choice == 0) {
                    System.out.println("Client stopped.");
                    break;
                }

                Request request = null;
                switch (choice) {
                    case 1 -> {
                        RecordDTO recordDTO = RecordDTO.builder()
                            .personId("P001")
                            .vaccineId("V015")
                            .status(DoseStatus.SCHEDULED)
                                .doseNumber(3)
                            .injectionDate(LocalDate.now().plusDays(10))
                            .build();

                        request = Request.builder()
                            .commandType(CommandType.CREATE_CORD)
                            .data(recordDTO)
                            .build();
                    }
                    case 2 -> request = Request.builder().commandType(CommandType.UPDATE_CORD).data(null).build();
                    case 3 -> request = Request.builder().commandType(CommandType.LIST_OBESE_PEOPLE).data(null).build();
                    case 4 -> request = Request.builder().commandType(CommandType.COUNT_VACCINES).data(null).build();
                    default -> {
                        System.out.println("Invalid choice.");
                        continue;
                    }
                }

                out.writeObject(request);
                out.flush();

                Object responseObject = in.readObject();
                if (responseObject instanceof Respond respond) {
                    System.out.println("Server response: " + respond);
                } else {
                    System.out.println("Unexpected response type: " + responseObject);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
